var words = ["nope", "nope", "nope", "nope", "nope", "nope", "nope", "here"];

var index = 0;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(0);
  
  fill(255);
  textSize(32);
  text(words[index], 160, 200);
}

function mousePressed() {
  index = index + 1;
  
  if (index == 8) {
    index = 0;
  }
}
